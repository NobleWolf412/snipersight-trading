"""
Default configuration for SniperSight scanner.

Following ARCHITECTURE.md institutional-grade defaults.
"""
from dataclasses import dataclass
from typing import Tuple, Optional

# Forward reference for PlannerConfig (avoid circular import)
try:
    from backend.shared.config.planner_config import PlannerConfig
except ImportError:
    PlannerConfig = None


@dataclass
class ScanConfig:
    """Core scanning configuration."""
    profile: str = "balanced"
    timeframes: Tuple[str, ...] = ('1W', '1D', '4H', '1H', '15m', '5m')
    min_confluence_score: float = 65.0
    min_rr_ratio: float = 0.8  # Temporarily lowered for testing
    btc_impulse_gate_enabled: bool = True
    # Macro overlay (dominance/flows) toggle - disabled by default until fully wired
    macro_overlay_enabled: bool = False
    max_symbols: int = 20
    max_risk_pct: float = 2.0
    leverage: int = 1  # Added: user-selected leverage to allow planner adaptive buffers/targets
    
    # SMC detection preset: 'defaults', 'luxalgo_strict', or 'sensitive'
    smc_preset: str = "luxalgo_strict"
    
    # Planner-specific knobs (wired from scanner mode)
    primary_planning_timeframe: str = "4H"
    max_pullback_atr: float = 3.0
    min_stop_atr: float = 1.0
    max_stop_atr: float = 6.0

    # HTF proximity integration knobs
    htf_proximity_enabled: bool = True
    htf_proximity_weight: float = 0.12
    htf_proximity_atr_max: float = 1.0
    htf_proximity_pct_max: float = 2.0
    htf_timeframes: Tuple[str, ...] = ('4H', '1D', '1W')
    htf_bias_entry: bool = True
    htf_bias_entry_offset_atr: float = 0.05
    htf_touch_fresh_days_max: int = 14

    # Real-time price / drift validation knobs
    max_entry_drift_pct: float = 0.15  # Reject if price moved >15% from planned avg entry
    max_entry_drift_atr: float = 3.0   # Or if drift exceeds 3 ATRs
    
    # Planner configuration (optional - will use defaults_for_mode if not set)
    planner: Optional['PlannerConfig'] = None


@dataclass
class GlobalThresholds:
    """Global indicator and analysis thresholds."""
    # ATR multipliers
    atr_stop_multiplier: float = 1.5
    atr_target_multiplier: float = 3.0
    atr_displacement_threshold: float = 2.0
    
    # RSI levels
    rsi_oversold: float = 30.0
    rsi_overbought: float = 70.0
    rsi_extreme_oversold: float = 20.0
    rsi_extreme_overbought: float = 80.0
    
    # Volume spike detection
    volume_spike_threshold: float = 2.0  # 2x average volume
    
    # Order block freshness
    ob_max_age_candles: int = 100
    ob_min_displacement_strength: float = 0.7
    
    # FVG size thresholds
    fvg_min_size_atr: float = 0.5


@dataclass
class WindowSizes:
    """Indicator calculation window sizes."""
    # EMA periods
    ema_fast: int = 20
    ema_medium: int = 50
    ema_slow: int = 200
    
    # RSI/Momentum
    rsi_period: int = 14
    stoch_rsi_period: int = 14
    mfi_period: int = 14
    
    # Volatility
    atr_period: int = 14
    bb_period: int = 20
    bb_std: float = 2.0
    
    # Volume
    volume_ma_period: int = 20
    
    # Lookback windows
    structure_lookback: int = 50
    liquidity_lookback: int = 20


# Default instances
DEFAULT_SCAN_CONFIG = ScanConfig()
DEFAULT_THRESHOLDS = GlobalThresholds()
DEFAULT_WINDOWS = WindowSizes()
