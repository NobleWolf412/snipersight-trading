# SniperSight Scanner Analysis Report
## Mode Logic, Entry/SL/TP Calculations, and Scoring Review

**Date:** December 29, 2025  
**Codebase Version:** snipersight-trading-main (extracted)

---

## Executive Summary

After deep analysis of the scanner logic, I've identified several issues with how swing trades are being calculated, particularly around entry zones, stop losses, and targets. The core problem: **the system treats swing trades like intraday trades with wider stops**, rather than identifying true swing points.

---

## 1. MODE-SPECIFIC LOGIC ANALYSIS

### 1.1 Current Mode Definitions

| Mode | Profile | Trade Type | Entry TFs | Stop TFs | Target TFs |
|------|---------|------------|-----------|----------|------------|
| **Overwatch** | macro_surveillance | Swing (Days-Weeks) | 1w,1d,4h,1h,15m | 4h,1h | 1d,4h |
| **Strike** | intraday_aggressive | Intraday (Hours) | 15m,5m | 1h,15m,5m | 1h,15m |
| **Surgical** | precision | Scalp/Intraday | 4h,1h,15m,5m | 4h,1h,15m,5m | 4h,1h,15m |
| **Stealth** | stealth_balanced | Balanced (Hours-Days) | 4h,1h,15m,5m | 4h,1h,15m | 1d,4h,1h,15m |

### 1.2 The "True Swing" Problem

**What you're experiencing:** Swing mode (Overwatch) produces entries that feel like scaled-up intraday trades rather than true swing setups.

**Root cause:** The system finds entries based on the **nearest** valid OB/FVG structure, rather than identifying the **swing invalidation point** that defines the trade thesis.

**Example of the problem:**
```
Market: BTC forming a higher low on the daily chart
True Swing Setup:
  - Entry: At 4H OB that formed during the HL formation
  - Stop: Below the DAILY swing low that started the HL
  - Target: Previous daily swing high or weekly resistance

Current System Behavior:
  - Entry: At 4H OB (correct)
  - Stop: Below the 4H OB (too tight for swing)
  - Target: 1.5R-2R mathematical projection (not structural)
```

---

## 2. ENTRY CALCULATION ANALYSIS

### 2.1 How Entries Work Now (`entry_engine.py`)

```python
# Current logic flow:
1. Get allowed_tfs from config.entry_timeframes
2. Find all OBs/FVGs in those timeframes
3. Filter for direction alignment (bullish OB below price for longs)
4. Apply Premium/Discount compliance
5. Score by freshness * timeframe_weight * displacement
6. Use best-scored OB/FVG for entry zone
```

**Issue:** The entry zone selection doesn't distinguish between:
- **HTF Zone OBs** (where institutions accumulate - 4H/1H zones)
- **LTF Entry Trigger OBs** (where to precisely enter - 15m/5m refinement)

**The `zone_timeframes` and `entry_trigger_timeframes` are defined but NOT USED:**
```python
# In scanner_modes.py - DEFINED BUT UNUSED IN ENTRY CALCULATION:
zone_timeframes=("4h", "1h"),        # Entry zone OBs
entry_trigger_timeframes=("15m", "5m"),  # Refined entry OBs inside zone
```

### 2.2 Recommended Entry Logic for Swings

For **Overwatch/Swing** mode, the entry logic should be:

```python
# PROPOSED TOP-DOWN ENTRY FLOW:
1. Identify HTF Bias (Weekly/Daily trend via swing structure)
2. Find Zone OB (4H/1H OB in direction of bias)
3. Wait for LTF Entry Trigger (15m/5m OB INSIDE the zone OB)
4. Entry = LTF trigger OB
5. Stop = Below HTF swing low (NOT the OB)
6. Target = HTF structural levels
```

---

## 3. STOP LOSS CALCULATION ANALYSIS

### 3.1 How Stops Work Now (`risk_engine.py`)

```python
# Current logic flow:
1. Look for OBs/FVGs in stop_timeframes
2. Find structure below entry (for longs)
3. Use closest structure as stop reference
4. Add ATR buffer below structure
5. Fallback: swing-based stop from candle data (limited lookback)
```

**Issue for Swings:** The stop is placed below the **entry structure** rather than below the **swing invalidation level**.

**Current behavior:**
```python
# For bullish, uses CLOSEST structure below entry:
if valid_stops:
    stop_level, structure_tf_used = max(valid_stops, key=lambda x: x[0])  # HIGHEST of valid stops
    stop_level -= (stop_buffer * atr)
```

This is **correct for intraday/scalps** but **wrong for swings**.

### 3.2 Swing Stop Detection Problem

The `_find_swing_level` function has limitations:

```python
# Current swing detection:
def _find_swing_level(..., lookback: int, timeframe: str):
    scaled_lookback = scale_lookback(lookback, timeframe)  # Problem: may be too small
    recent = candles_df.tail(scaled_lookback)
    # Uses tiered approach: strict swing -> relaxed swing -> simple min
```

**Issues:**
1. **Lookback too short**: Default `stop_lookback_bars` in PlannerConfig might be too small for HTF swings
2. **Doesn't find THE significant swing**: Just finds A swing in the lookback period
3. **No connection to market structure**: Should find the swing that created the structure (HL/LL)

### 3.3 Recommended Stop Logic for Swings

```python
# PROPOSED SWING STOP LOGIC:
For OVERWATCH/SWING mode:
1. Identify the swing structure (HH/HL pattern for bullish)
2. Find the SWING LOW that defines the higher low structure
3. Stop = Below that swing low (with buffer)
4. This might be 3-6 ATR away from entry - THAT'S OKAY FOR SWINGS

Example:
  Entry at: $100 (4H OB)
  Last HL swing low: $92 (Daily timeframe)
  Stop: $90 (below the HL)
  This is 10% risk, but it's a SWING trade - size accordingly
```

---

## 4. TARGET CALCULATION ANALYSIS

### 4.1 How Targets Work Now

For swing modes, `_calculate_targets` uses structural targeting:

```python
# Current structural target sources:
1. HTF Swings (_find_htf_swing_targets)
2. BOS Levels (_get_htf_bos_levels) 
3. EQH/EQL Liquidity pools (_find_eqh_eql_zones)
4. Fib Extensions (_calculate_fib_extensions)
5. Unfilled HTF FVGs (_get_unfilled_htf_fvgs)
6. Fallback: _calculate_swing_structural_targets (Key Levels + ATR projection)
```

**This is actually solid.** The issue is that `_find_htf_swing_targets`:
```python
def _find_htf_swing_targets(...):
    # Priority 1: Use pre-calculated HTF levels from smc_snapshot.htf_levels
    if smc_snapshot and getattr(smc_snapshot, 'htf_levels', None):
        # ... use them
    
    # If no HTF levels found, return empty!
    # NO FALLBACK TO CANDLE-BASED SWING DETECTION
    return swing_levels
```

**Problem:** If `htf_levels` isn't populated by the analysis modules, there's no fallback.

---

## 5. SCORING SYSTEM ANALYSIS

### 5.1 Factor Weight Summary (Overwatch Mode)

| Factor | Weight | Purpose |
|--------|--------|---------|
| order_block | 0.25 | Entry zone quality |
| market_structure | 0.20 | BOS/CHoCH detection |
| fvg | 0.18 | Imbalance zones |
| liquidity_sweep | 0.18 | Stop hunt confirmation |
| htf_alignment | 0.25 | Multi-TF direction |
| htf_proximity | 0.15 | Near HTF level bonus |
| htf_inflection | 0.18 | At HTF inflection point |
| htf_structure_bias | 0.15 | HTF bias direction |
| institutional_sequence | 0.15 | OB+BOS+FVG sequence |
| btc_impulse | 0.12 | BTC leading indicator |
| weekly_stoch_rsi | 0.12 | HTF momentum |
| premium_discount | 0.12 | Value zone |
| multi_tf_reversal | 0.12 | Reversal alignment |
| momentum | 0.08 | RSI/Stoch/MFI/MACD |
| volume | 0.10 | Volume confirmation |
| volatility | 0.08 | ATR% zone |
| inside_ob | 0.10 | Nested OB bonus |
| nested_ob | 0.10 | OB inside OB |
| opposing_structure | 0.06 | **Penalty** for resistance ahead |
| timeframe_conflict | 0.10 | **Penalty** for TF disagreement |
| kill_zone | 0.03 | Session timing |
| ltf_structure_shift | 0.05 | LTF confirmation |
| macd_veto | 0.05 | MACD opposition penalty |

### 5.2 Potential Redundancy/Overlap Issues

**Group 1: MACD-Related (Potential Redundancy)**
- `momentum` factor includes MACD scoring (via `_score_momentum`)
- `macd_veto` is a separate penalty factor
- Mode-aware MACD is evaluated separately in `evaluate_macd_for_mode`

**Assessment:** The MACD logic is actually well-designed:
- `momentum` gives base MACD score
- Mode-aware evaluation adjusts weight
- `macd_veto` handles LTF opposition penalty

**Verdict:** ✅ Not redundant - serves different purposes

---

**Group 2: HTF-Related Factors (Many but Distinct)**
- `htf_alignment`: Overall HTF trend direction alignment
- `htf_proximity`: Distance to nearest HTF level (bonus for being close)
- `htf_inflection`: At a key HTF turning point
- `htf_structure_bias`: HTF structure favors trade direction

**Assessment:** These measure different aspects:
- Alignment = direction
- Proximity = location
- Inflection = timing
- Bias = confirmation

**Verdict:** ✅ Distinct purposes - keep separate

---

**Group 3: Volume-Related**
- `volume`: Volume spike + acceleration scoring
- `liquidity_sweep`: Includes volume confirmation check

**Assessment:** 
- `volume` scores general volume conditions
- `liquidity_sweep` checks if a sweep was volume-confirmed

**Verdict:** ✅ Distinct - one is condition, one is pattern confirmation

---

**Group 4: Structure Scoring**
- `order_block`: Entry zone quality
- `fvg`: Imbalance zones
- `market_structure`: BOS/CHoCH breaks
- `inside_ob` / `nested_ob`: OB positioning bonuses

**Assessment:** Each scores a different SMC concept

**Verdict:** ✅ Distinct - each measures different structural element

---

### 5.3 Scoring Issues Found

**Issue 1: Momentum Base Score Bug (FIXED in code but verify)**
```python
# In _score_momentum (line 2710):
score = 0.0  # FIXED: Was 40.0 which inflated momentum even with no signals
```
Good - this was caught and fixed.

**Issue 2: Weight Sum Exceeds 1.0**

Adding up Overwatch weights:
```
0.25 + 0.20 + 0.18 + 0.18 + 0.25 + 0.15 + 0.18 + 0.15 + 0.15 + 
0.12 + 0.12 + 0.12 + 0.12 + 0.08 + 0.10 + 0.08 + 0.10 + 0.10 + 
0.06 + 0.10 + 0.03 + 0.05 + 0.05 = 2.82
```

**This is intentional** - weights aren't normalized to 1.0. The final score is capped at 100 anyway. But it means:
- Some factors can be "free points"
- A perfect setup with all factors aligned could theoretically score 282
- Only 100 needed to pass

**This is fine** as long as the minimum confluence threshold is calibrated correctly.

---

## 6. RECOMMENDATIONS

### 6.1 High Priority: Fix Swing Stop Logic

**File:** `backend/strategy/planner/risk_engine.py`

Add a new function for swing-specific stop calculation:

```python
def _calculate_swing_invalidation_stop(
    is_bullish: bool,
    smc_snapshot: SMCSnapshot,
    multi_tf_data: MultiTimeframeData,
    atr: float,
    config: ScanConfig
) -> Optional[float]:
    """
    Find the swing low/high that defines the trade structure.
    For swings, this is the HL that started the bullish structure (longs)
    or the LH that started bearish structure (shorts).
    """
    # Get swing structure from HTF
    htf_tfs = ['1d', '4h']
    
    for tf in htf_tfs:
        if tf in multi_tf_data.timeframes:
            swing_struct = detect_swing_structure(
                multi_tf_data.timeframes[tf],
                lookback=30,  # Larger lookback for HTF
                min_swing_atr=0.3
            )
            
            if is_bullish and swing_struct.last_hl:
                # Stop below the higher low
                return swing_struct.last_hl.price
            elif not is_bullish and swing_struct.last_lh:
                # Stop above the lower high
                return swing_struct.last_lh.price
    
    return None
```

Then use it in `_calculate_stop_loss` for swing modes:

```python
# In _calculate_stop_loss, add:
mode_profile = getattr(config, 'profile', 'balanced')
is_swing_mode = mode_profile in ('macro_surveillance', 'overwatch')

if is_swing_mode:
    swing_stop = _calculate_swing_invalidation_stop(...)
    if swing_stop:
        # Use swing invalidation as primary stop
        stop_level = swing_stop - (stop_buffer * atr) if is_bullish else swing_stop + (stop_buffer * atr)
        rationale = f"Stop beyond {primary_tf} swing invalidation point"
        # Continue with validation...
```

### 6.2 Medium Priority: Implement Top-Down Entry Logic

**File:** `backend/strategy/planner/entry_engine.py`

Add nested OB entry logic:

```python
def _find_nested_entry(
    is_bullish: bool,
    zone_obs: List[OrderBlock],  # HTF zone OBs (4H/1H)
    trigger_obs: List[OrderBlock],  # LTF trigger OBs (15m/5m)
    current_price: float
) -> Optional[OrderBlock]:
    """
    Find LTF trigger OB that sits inside an HTF zone OB.
    """
    for zone_ob in zone_obs:
        for trigger_ob in trigger_obs:
            # Check if trigger is inside zone
            if (trigger_ob.low >= zone_ob.low and 
                trigger_ob.high <= zone_ob.high):
                return trigger_ob
    return None
```

### 6.3 Low Priority: Add HTF Swing Target Fallback

**File:** `backend/strategy/planner/risk_engine.py`

In `_find_htf_swing_targets`, add candle-based fallback:

```python
# At end of function, before return:
if not swing_levels and multi_tf_data:
    # Fallback to candle-based swing detection
    for tf in allowed_tfs:
        df = multi_tf_data.timeframes.get(tf)
        if df is not None and len(df) >= 50:
            swing_struct = detect_swing_structure(df, lookback=20)
            
            if is_bullish:
                # Find swing highs above entry
                for sp in swing_struct.swing_points:
                    if sp.is_high and sp.price > avg_entry:
                        swing_levels.append((sp.price, tf, 1))
            else:
                for sp in swing_struct.swing_points:
                    if not sp.is_high and sp.price < avg_entry:
                        swing_levels.append((sp.price, tf, 1))
            
            if swing_levels:
                break
```

---

## 7. VALIDATION QUESTIONS FOR YOU

Before implementing, confirm these assumptions:

1. **For Overwatch swing trades:**
   - Entry: Should we enter at the HTF zone OB directly, or wait for LTF trigger OB inside it?
   - Stop: Below the HTF swing low (might be 5-10% away) - acceptable?
   - Target: Previous HTF swing high - correct?

2. **Position sizing:**
   - With wider stops, you'd need smaller position sizes
   - Should the system calculate suggested position size based on stop distance?

3. **Scoring:**
   - Are there specific factors you feel are giving false positives?
   - Should some factors be mandatory (hard gate) vs weighted?

---

## 8. FILES TO MODIFY

| File | Changes |
|------|---------|
| `risk_engine.py` | Add `_calculate_swing_invalidation_stop`, modify stop logic for swing modes |
| `entry_engine.py` | Implement nested entry logic using `zone_timeframes` and `entry_trigger_timeframes` |
| `scanner_modes.py` | Potentially adjust ATR constraints for swing mode |
| `planner_config.py` | Add swing-specific parameters |
| `swing_structure.py` | Increase default lookback, add swing significance scoring |

---

*End of Analysis Report*
