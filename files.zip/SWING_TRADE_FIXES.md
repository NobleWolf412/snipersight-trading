# SniperSight Swing Trade Fixes

## Changes Made

### 1. `backend/strategy/planner/risk_engine.py`

**New Function: `_calculate_swing_invalidation_stop()`** (Lines 162-268)
- Finds the HTF swing point (HL/LH) that defines the trade structure
- Uses `detect_swing_structure()` with larger lookback (20-30 candles)
- Prioritizes Daily → 4H → 1H timeframes for swing invalidation
- Returns the swing level, timeframe, and swing type (HL/LH)

**Modified: `_calculate_stop_loss()`** (Lines ~317-360)
- Added swing mode detection check (`macro_surveillance`, `overwatch`)
- For swing modes, calls `_calculate_swing_invalidation_stop()` FIRST
- Uses swing invalidation level as stop reference (instead of entry OB)
- Falls back to original OB-based logic if swing stop too wide or not found

**Enhanced: `_find_htf_swing_targets()`** (Lines ~795-850)
- Added candle-based swing detection fallback when `htf_levels` not populated
- Uses `detect_swing_structure()` to find swing highs/lows for targets
- Prevents empty targets when analysis modules don't provide HTF levels

### 2. `backend/strategy/planner/entry_engine.py`

**New Function: `_find_nested_entry_ob()`** (Lines 175-250)
- Finds LTF trigger OB inside HTF zone OB for precision entry
- Implements top-down entry logic (zone → trigger)
- Scores nested setups by freshness, zone size, mitigation

**New Function: `_get_zone_and_trigger_tfs()`** (Lines 252-270)
- Extracts zone and trigger timeframes from config
- Falls back to splitting entry_timeframes if not specified

**Modified: `_calculate_entry_zone()`** (Lines ~300-370)
- Added swing mode detection for Overwatch and Stealth
- Attempts nested entry first for swing modes
- Uses LTF trigger OB for precise entry, notes HTF zone in rationale
- Falls back to standard logic if no nested setup found

### 3. `backend/shared/config/scanner_modes.py`

**Updated: Overwatch Mode** (Lines 161-186)
- `max_stop_atr`: 6.5 → 8.0 (allow wider swing stops)
- `stop_timeframes`: Added `1d` for daily swing invalidation
- `htf_swing_allowed`: Added `1h` to the allowlist

---

## How It Works Now

### For Overwatch (Swing) Mode:

**Entry Logic:**
1. Look for nested entry: LTF trigger OB (15m/5m) inside HTF zone OB (4h/1h)
2. If found: Use trigger OB for precise entry, zone OB noted in rationale
3. If not found: Fall back to best-scored OB from entry_timeframes

**Stop Logic:**
1. Find HTF swing invalidation: HL (for longs) or LH (for shorts) on 1D/4H/1H
2. If found: Place stop beyond swing level + ATR buffer
3. If too wide (>8 ATR) or not found: Fall back to entry OB-based stop

**Target Logic:**
1. Use pre-calculated HTF levels if available
2. Fallback: Detect swing highs/lows from candle data
3. Combine with BOS levels, EQH/EQL, and Fib extensions

### Example Trade Flow:

```
BTC forming Higher Low on Daily chart:

BEFORE (Old Logic):
  Entry: 4H OB at $95,000
  Stop: Below 4H OB at $94,500 (0.5% risk)
  Target: 1.5R mathematical projection at $95,750
  Problem: This is an intraday trade, not a swing

AFTER (New Logic):
  Entry: 15m OB at $95,200 (inside 4H zone $94,800-$95,500)
  Stop: Below Daily HL at $92,000 (3.4% risk)
  Target: Previous Daily swing high at $100,000
  Result: True swing trade with proper structure
```

---

## Testing

Run the scanner in Overwatch mode and verify:

1. **Stops appear wider** - Should see stops 3-8 ATR away, not 0.5-2 ATR
2. **Logs show "SWING STOP ACTIVE"** - Confirms new logic is being used
3. **Logs show "NESTED ENTRY ACTIVE"** - Confirms top-down entry working
4. **Targets hit HTF levels** - PWH, PDH, daily swings, not just R multiples

---

## Rollback

If issues arise, revert the three modified files:
- `backend/strategy/planner/risk_engine.py`
- `backend/strategy/planner/entry_engine.py`
- `backend/shared/config/scanner_modes.py`
