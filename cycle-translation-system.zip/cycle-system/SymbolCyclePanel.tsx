/**
 * SymbolCyclePanel - Full cycle intelligence panel for a symbol
 * 
 * Shows detailed DCL and WCL cycle information with:
 * - Visual progress bars
 * - Translation indicators
 * - Peak detection
 * - Cycle low windows
 * - Warnings and alerts
 * 
 * Usage:
 *   <SymbolCyclePanel symbol="ETH/USDT" />
 */

import React, { useEffect, useState } from 'react';
import { api, SymbolCyclesData, CycleStateData } from '../../utils/api';

interface SymbolCyclePanelProps {
  symbol: string;
  exchange?: string;
  onLoad?: (data: SymbolCyclesData) => void;
  initialData?: SymbolCyclesData;
  className?: string;
}

export const SymbolCyclePanel: React.FC<SymbolCyclePanelProps> = ({
  symbol,
  exchange = 'bybit',
  onLoad,
  initialData,
  className = ''
}) => {
  const [data, setData] = useState<SymbolCyclesData | null>(initialData || null);
  const [loading, setLoading] = useState(!initialData);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (initialData) return;
    
    const fetchCycles = async () => {
      setLoading(true);
      setError(null);
      
      try {
        const response = await api.getSymbolCycles(symbol, exchange);
        if (response.data?.status === 'success' && response.data.data) {
          setData(response.data.data);
          onLoad?.(response.data.data);
        } else {
          setError(response.data?.error || 'Failed to load cycle data');
        }
      } catch (e) {
        setError('Network error loading cycles');
      } finally {
        setLoading(false);
      }
    };

    fetchCycles();
  }, [symbol, exchange, initialData, onLoad]);

  if (loading) {
    return (
      <div className={`bg-slate-800/50 rounded-lg p-4 ${className}`}>
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-slate-700 rounded w-1/3"></div>
          <div className="h-24 bg-slate-700 rounded"></div>
          <div className="h-24 bg-slate-700 rounded"></div>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className={`bg-slate-800/50 rounded-lg p-4 ${className}`}>
        <div className="text-red-400 text-sm">
          ⚠️ {error || 'No cycle data available'}
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-slate-800/50 rounded-lg overflow-hidden ${className}`}>
      {/* Header */}
      <div className="bg-slate-700/50 px-4 py-3 border-b border-slate-600/50">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-white flex items-center gap-2">
            <span className="text-cyan-400">⟡</span>
            {symbol} Cycle Intelligence
          </h3>
          <OverallBiasTag bias={data.overall_bias} alignment={data.alignment} />
        </div>
      </div>

      {/* Cycles Grid */}
      <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        <CycleCard cycle={data.dcl} title="Daily Cycle (DCL)" />
        <CycleCard cycle={data.wcl} title="Weekly Cycle (WCL)" />
      </div>

      {/* Warnings */}
      {data.warnings && data.warnings.length > 0 && (
        <div className="px-4 pb-4">
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3">
            <div className="text-amber-400 text-sm font-medium mb-1">Cycle Warnings</div>
            <ul className="space-y-1">
              {data.warnings.map((warning, idx) => (
                <li key={idx} className="text-amber-400/80 text-xs flex items-start gap-2">
                  <span className="mt-0.5">•</span>
                  <span>{warning}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Alerts */}
      {data.alerts && data.alerts.length > 0 && (
        <div className="px-4 pb-4 space-y-2">
          {data.alerts.map((alert, idx) => (
            <div
              key={idx}
              className={`
                rounded-lg p-3 text-sm
                ${alert.type === 'CRITICAL' 
                  ? 'bg-red-500/20 border border-red-500/50 text-red-300'
                  : alert.type === 'WARNING'
                  ? 'bg-amber-500/20 border border-amber-500/50 text-amber-300'
                  : 'bg-cyan-500/20 border border-cyan-500/50 text-cyan-300'
                }
              `}
            >
              <div className="font-medium">{alert.message}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/**
 * Overall bias tag
 */
interface OverallBiasTagProps {
  bias: 'LONG' | 'SHORT' | 'NEUTRAL';
  alignment: 'ALIGNED' | 'MIXED' | 'CONFLICTING';
}

const OverallBiasTag: React.FC<OverallBiasTagProps> = ({ bias, alignment }) => {
  const colors = {
    LONG: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50',
    SHORT: 'bg-red-500/20 text-red-400 border-red-500/50',
    NEUTRAL: 'bg-slate-500/20 text-slate-400 border-slate-500/50'
  };

  const alignmentIcon = {
    ALIGNED: '✓',
    MIXED: '◐',
    CONFLICTING: '⚠'
  };

  return (
    <div className={`px-2 py-1 rounded-md border text-xs font-medium ${colors[bias]}`}>
      {alignmentIcon[alignment]} {bias}
    </div>
  );
};

/**
 * Single cycle card (DCL or WCL)
 */
interface CycleCardProps {
  cycle: CycleStateData;
  title: string;
}

const CycleCard: React.FC<CycleCardProps> = ({ cycle, title }) => {
  const {
    bars_since_low,
    expected_length,
    midpoint,
    cycle_low,
    cycle_high,
    translation,
    translation_pct,
    is_failed,
    is_in_window,
    status,
    bias
  } = cycle;

  // Calculate progress percentage
  const maxLen = expected_length.max;
  const progress = Math.min((bars_since_low / maxLen) * 100, 100);
  const midpointPct = (midpoint / maxLen) * 100;

  // Translation display
  const getTranslationDisplay = () => {
    if (translation === 'right_translated') return { label: 'RTR', color: 'text-emerald-400', desc: 'Right Translated (Bullish)' };
    if (translation === 'left_translated') return { label: 'LTR', color: 'text-red-400', desc: 'Left Translated (Bearish)' };
    if (translation === 'mid_translated') return { label: 'MTR', color: 'text-amber-400', desc: 'Mid Translated (Neutral)' };
    return { label: '???', color: 'text-slate-400', desc: 'Unknown' };
  };

  const trans = getTranslationDisplay();

  // Status colors
  const statusColors = {
    healthy: 'text-emerald-400',
    caution: 'text-amber-400',
    warning: 'text-orange-400',
    failed: 'text-red-400',
    early: 'text-cyan-400',
    unknown: 'text-slate-400'
  };

  // Bias colors
  const biasColors = {
    LONG: 'bg-emerald-500/20 text-emerald-400',
    SHORT: 'bg-red-500/20 text-red-400',
    NEUTRAL: 'bg-slate-500/20 text-slate-400'
  };

  return (
    <div className={`
      bg-slate-700/30 rounded-lg p-4 border
      ${is_failed 
        ? 'border-red-500/50 bg-red-500/5' 
        : is_in_window 
        ? 'border-cyan-500/50 bg-cyan-500/5'
        : 'border-slate-600/50'
      }
    `}>
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="font-medium text-white">{title}</div>
        <div className={`px-2 py-0.5 rounded text-xs font-bold ${biasColors[bias]}`}>
          {bias}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-3">
        <div className="flex justify-between text-xs text-slate-400 mb-1">
          <span>Day {bars_since_low}</span>
          <span>/ {expected_length.min}-{expected_length.max}</span>
        </div>
        <div className="relative h-3 bg-slate-600/50 rounded-full overflow-hidden">
          {/* Midpoint marker */}
          <div 
            className="absolute top-0 bottom-0 w-0.5 bg-white/30 z-10"
            style={{ left: `${midpointPct}%` }}
          />
          
          {/* Window zone */}
          <div 
            className="absolute top-0 bottom-0 bg-cyan-500/20"
            style={{ 
              left: `${(expected_length.min / maxLen) * 100}%`,
              width: `${((expected_length.max - expected_length.min) / maxLen) * 100}%`
            }}
          />
          
          {/* Progress fill */}
          <div 
            className={`
              absolute top-0 bottom-0 left-0 rounded-full transition-all duration-300
              ${is_failed 
                ? 'bg-red-500' 
                : translation === 'right_translated'
                ? 'bg-emerald-500'
                : translation === 'left_translated'
                ? 'bg-red-500'
                : 'bg-amber-500'
              }
            `}
            style={{ width: `${progress}%` }}
          />

          {/* Peak marker (if we have it) */}
          {cycle_high.peak_bar && cycle_high.peak_bar > 0 && (
            <div 
              className="absolute top-0 bottom-0 w-1 bg-white/70 z-20"
              style={{ left: `${(cycle_high.peak_bar / maxLen) * 100}%` }}
              title={`Peak at Day ${cycle_high.peak_bar}`}
            />
          )}
        </div>
        <div className="flex justify-between text-xs text-slate-500 mt-1">
          <span>Low</span>
          <span className="text-white/30">↑ Mid</span>
          <span>High</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-2 text-xs">
        {/* Translation */}
        <div className="bg-slate-800/50 rounded p-2">
          <div className="text-slate-400 mb-0.5">Translation</div>
          <div className={`font-bold ${trans.color}`}>
            {trans.label} 
            <span className="font-normal opacity-70 ml-1">
              ({translation_pct.toFixed(0)}%)
            </span>
          </div>
        </div>

        {/* Status */}
        <div className="bg-slate-800/50 rounded p-2">
          <div className="text-slate-400 mb-0.5">Status</div>
          <div className={`font-bold ${statusColors[status as keyof typeof statusColors] || 'text-slate-400'}`}>
            {is_failed ? '🚨 FAILED' : status.toUpperCase()}
          </div>
        </div>

        {/* Cycle Low */}
        <div className="bg-slate-800/50 rounded p-2">
          <div className="text-slate-400 mb-0.5">Cycle Low</div>
          <div className="text-white font-mono">
            ${cycle_low.price.toLocaleString(undefined, { maximumFractionDigits: 2 })}
          </div>
        </div>

        {/* Cycle High */}
        <div className="bg-slate-800/50 rounded p-2">
          <div className="text-slate-400 mb-0.5">Cycle High</div>
          <div className="text-white font-mono">
            {cycle_high.price 
              ? `$${cycle_high.price.toLocaleString(undefined, { maximumFractionDigits: 2 })}`
              : '—'
            }
          </div>
        </div>
      </div>

      {/* Window Indicator */}
      {is_in_window && !is_failed && (
        <div className="mt-3 bg-cyan-500/20 border border-cyan-500/30 rounded p-2 text-xs text-cyan-300">
          <span className="font-bold">◉ IN CYCLE LOW WINDOW</span>
          <span className="opacity-70 ml-2">Watch for bounce confirmation</span>
        </div>
      )}

      {/* Failed Warning */}
      {is_failed && (
        <div className="mt-3 bg-red-500/20 border border-red-500/30 rounded p-2 text-xs text-red-300 animate-pulse">
          <span className="font-bold">🚨 CYCLE FAILED</span>
          <span className="opacity-70 ml-2">Price broke below cycle low - bearish confirmed</span>
        </div>
      )}
    </div>
  );
};

export default SymbolCyclePanel;
