/**
 * CycleBadge - Compact cycle status indicator
 * 
 * Shows translation status (RTR/MTR/LTR) with color coding:
 * - RTR (Right Translated) = Green = Bullish
 * - MTR (Mid Translated) = Yellow = Neutral
 * - LTR (Left Translated) = Red = Bearish
 * - FAILED = Red pulsing = Confirmed bearish
 */

import React from 'react';
import { TranslationType, CycleStatusType, CycleBiasType } from '../../utils/api';

interface CycleBadgeProps {
  cycleType: 'DCL' | 'WCL' | '4YC';
  translation: TranslationType | 'RTR' | 'MTR' | 'LTR';
  status: CycleStatusType | string;
  day?: number;
  expectedRange?: string;  // e.g., "18-28"
  isFailed?: boolean;
  isInWindow?: boolean;
  showDay?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const CycleBadge: React.FC<CycleBadgeProps> = ({
  cycleType,
  translation,
  status,
  day,
  expectedRange,
  isFailed = false,
  isInWindow = false,
  showDay = true,
  size = 'md',
  className = ''
}) => {
  // Normalize translation to short form
  const getShortTranslation = (): string => {
    if (translation === 'right_translated' || translation === 'RTR') return 'RTR';
    if (translation === 'mid_translated' || translation === 'MTR') return 'MTR';
    if (translation === 'left_translated' || translation === 'LTR') return 'LTR';
    return '???';
  };

  // Get color based on translation/status
  const getColors = () => {
    if (isFailed) {
      return {
        bg: 'bg-red-500/20',
        border: 'border-red-500/50',
        text: 'text-red-400',
        icon: '🚨',
        pulse: true
      };
    }

    const trans = getShortTranslation();
    
    if (trans === 'RTR') {
      return {
        bg: 'bg-emerald-500/20',
        border: 'border-emerald-500/50',
        text: 'text-emerald-400',
        icon: '🟢',
        pulse: false
      };
    }
    
    if (trans === 'LTR') {
      return {
        bg: 'bg-red-500/20',
        border: 'border-red-500/50',
        text: 'text-red-400',
        icon: '🔴',
        pulse: false
      };
    }
    
    // MTR or unknown
    return {
      bg: 'bg-amber-500/20',
      border: 'border-amber-500/50',
      text: 'text-amber-400',
      icon: '🟡',
      pulse: false
    };
  };

  const colors = getColors();
  const shortTrans = getShortTranslation();

  // Size classes
  const sizeClasses = {
    sm: 'text-xs px-1.5 py-0.5 gap-1',
    md: 'text-xs px-2 py-1 gap-1.5',
    lg: 'text-sm px-2.5 py-1.5 gap-2'
  };

  return (
    <div
      className={`
        inline-flex items-center rounded-md border font-mono
        ${colors.bg} ${colors.border} ${colors.text}
        ${sizeClasses[size]}
        ${colors.pulse ? 'animate-pulse' : ''}
        ${className}
      `}
      title={`${cycleType}: ${shortTrans} - ${status}${day ? ` (Day ${day})` : ''}`}
    >
      {/* Cycle Type Label */}
      <span className="font-semibold opacity-70">{cycleType}</span>
      
      {/* Day Counter (optional) */}
      {showDay && day !== undefined && (
        <span className="opacity-60">
          D{day}{expectedRange ? `/${expectedRange.split('-')[1]}` : ''}
        </span>
      )}
      
      {/* Translation */}
      <span className="font-bold">{isFailed ? 'FAIL' : shortTrans}</span>
      
      {/* Window Indicator */}
      {isInWindow && !isFailed && (
        <span className="text-cyan-400" title="In cycle low window">
          ◉
        </span>
      )}
    </div>
  );
};

/**
 * CycleBadgeMinimal - Ultra-compact version for tight spaces
 */
interface CycleBadgeMinimalProps {
  translation: TranslationType | 'RTR' | 'MTR' | 'LTR';
  isFailed?: boolean;
  className?: string;
}

export const CycleBadgeMinimal: React.FC<CycleBadgeMinimalProps> = ({
  translation,
  isFailed = false,
  className = ''
}) => {
  const getShortTranslation = (): string => {
    if (translation === 'right_translated' || translation === 'RTR') return 'RTR';
    if (translation === 'mid_translated' || translation === 'MTR') return 'MTR';
    if (translation === 'left_translated' || translation === 'LTR') return 'LTR';
    return '???';
  };

  const trans = getShortTranslation();
  
  if (isFailed) {
    return <span className={`text-red-400 font-bold animate-pulse ${className}`}>🚨</span>;
  }
  
  if (trans === 'RTR') {
    return <span className={`text-emerald-400 ${className}`}>🟢</span>;
  }
  
  if (trans === 'LTR') {
    return <span className={`text-red-400 ${className}`}>🔴</span>;
  }
  
  return <span className={`text-amber-400 ${className}`}>🟡</span>;
};

export default CycleBadge;
