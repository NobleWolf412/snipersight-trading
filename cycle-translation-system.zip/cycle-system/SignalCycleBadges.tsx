/**
 * SignalCycleBadges - Cycle context badges for scanner signals
 * 
 * Displays DCL + WCL (symbol-specific) + 4YC (BTC macro) badges
 * for each trading signal to show cycle alignment.
 * 
 * Usage:
 *   <SignalCycleBadges 
 *     symbolCycles={symbolCyclesData}
 *     btcMacroBias="BULLISH"
 *     signalDirection="LONG"
 *   />
 */

import React from 'react';
import { CycleBadge, CycleBadgeMinimal } from './CycleBadge';
import { 
  SymbolCyclesData, 
  CycleStateData,
  CycleBiasType 
} from '../../utils/api';

interface SignalCycleBadgesProps {
  symbolCycles: SymbolCyclesData | null;
  btcMacroBias?: 'BULLISH' | 'NEUTRAL' | 'BEARISH';
  btc4YCPhase?: string;
  signalDirection?: 'LONG' | 'SHORT';
  compact?: boolean;
  showWarnings?: boolean;
  className?: string;
}

export const SignalCycleBadges: React.FC<SignalCycleBadgesProps> = ({
  symbolCycles,
  btcMacroBias,
  btc4YCPhase,
  signalDirection,
  compact = false,
  showWarnings = true,
  className = ''
}) => {
  if (!symbolCycles) {
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        <span className="text-xs text-slate-500 italic">Cycle data loading...</span>
      </div>
    );
  }

  const { dcl, wcl, warnings, alignment } = symbolCycles;

  // Check signal alignment
  const isSignalAligned = (cycle: CycleStateData, direction?: 'LONG' | 'SHORT'): boolean => {
    if (!direction) return true;
    if (direction === 'LONG') {
      return cycle.bias === 'LONG' || cycle.bias === 'NEUTRAL';
    }
    return cycle.bias === 'SHORT' || cycle.bias === 'NEUTRAL';
  };

  const dcl_aligned = isSignalAligned(dcl, signalDirection);
  const wcl_aligned = isSignalAligned(wcl, signalDirection);
  
  // Check 4YC alignment
  const macro_aligned = !signalDirection || !btcMacroBias || 
    (signalDirection === 'LONG' && btcMacroBias !== 'BEARISH') ||
    (signalDirection === 'SHORT' && btcMacroBias !== 'BULLISH');

  // Calculate overall alignment
  const allAligned = dcl_aligned && wcl_aligned && macro_aligned;
  const anyConflict = (!dcl_aligned || !wcl_aligned || !macro_aligned);

  // Compact mode - just icons
  if (compact) {
    return (
      <div className={`flex items-center gap-1 ${className}`}>
        <CycleBadgeMinimal 
          translation={dcl.translation}
          isFailed={dcl.is_failed}
        />
        <CycleBadgeMinimal 
          translation={wcl.translation}
          isFailed={wcl.is_failed}
        />
        {btcMacroBias && (
          <span className={
            btcMacroBias === 'BULLISH' ? 'text-emerald-400' :
            btcMacroBias === 'BEARISH' ? 'text-red-400' :
            'text-amber-400'
          }>
            {btcMacroBias === 'BULLISH' ? '🟢' : btcMacroBias === 'BEARISH' ? '🔴' : '🟡'}
          </span>
        )}
        {anyConflict && signalDirection && (
          <span className="text-amber-400 text-xs">⚠️</span>
        )}
      </div>
    );
  }

  // Full mode with badges
  return (
    <div className={`space-y-2 ${className}`}>
      {/* Badges Row */}
      <div className="flex flex-wrap items-center gap-2">
        {/* DCL Badge */}
        <div className={!dcl_aligned && signalDirection ? 'ring-1 ring-amber-500/50 rounded-md' : ''}>
          <CycleBadge
            cycleType="DCL"
            translation={dcl.translation}
            status={dcl.status}
            day={dcl.bars_since_low}
            expectedRange={`${dcl.expected_length.min}-${dcl.expected_length.max}`}
            isFailed={dcl.is_failed}
            isInWindow={dcl.is_in_window}
            size="md"
          />
        </div>

        {/* WCL Badge */}
        <div className={!wcl_aligned && signalDirection ? 'ring-1 ring-amber-500/50 rounded-md' : ''}>
          <CycleBadge
            cycleType="WCL"
            translation={wcl.translation}
            status={wcl.status}
            day={wcl.bars_since_low}
            expectedRange={`${wcl.expected_length.min}-${wcl.expected_length.max}`}
            isFailed={wcl.is_failed}
            isInWindow={wcl.is_in_window}
            size="md"
          />
        </div>

        {/* 4YC Badge (BTC Macro) */}
        {btcMacroBias && (
          <div className={!macro_aligned && signalDirection ? 'ring-1 ring-amber-500/50 rounded-md' : ''}>
            <div className={`
              inline-flex items-center gap-1.5 rounded-md border px-2 py-1 text-xs font-mono
              ${btcMacroBias === 'BULLISH' 
                ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
                : btcMacroBias === 'BEARISH'
                ? 'bg-red-500/20 border-red-500/50 text-red-400'
                : 'bg-amber-500/20 border-amber-500/50 text-amber-400'
              }
            `}>
              <span className="font-semibold opacity-70">4YC</span>
              {btc4YCPhase && <span className="opacity-60">{btc4YCPhase}</span>}
              <span className="font-bold">
                {btcMacroBias === 'BULLISH' ? 'RTR' : btcMacroBias === 'BEARISH' ? 'LTR' : 'MTR'}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Alignment Summary */}
      {signalDirection && (
        <div className={`
          flex items-center gap-2 text-xs
          ${allAligned ? 'text-emerald-400' : anyConflict ? 'text-amber-400' : 'text-slate-400'}
        `}>
          {allAligned ? (
            <>
              <span>✓</span>
              <span>All cycles support {signalDirection}</span>
            </>
          ) : (
            <>
              <span>⚠️</span>
              <span>Cycle conflict - review before entry</span>
            </>
          )}
        </div>
      )}

      {/* Warnings */}
      {showWarnings && warnings && warnings.length > 0 && (
        <div className="space-y-1">
          {warnings.slice(0, 2).map((warning, idx) => (
            <div key={idx} className="text-xs text-amber-400/80 flex items-start gap-1">
              <span className="mt-0.5">•</span>
              <span>{warning}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/**
 * CycleAlignmentIndicator - Simple alignment indicator
 * 
 * Shows overall cycle alignment with a single icon/color
 */
interface CycleAlignmentIndicatorProps {
  symbolCycles: SymbolCyclesData | null;
  btcMacroBias?: 'BULLISH' | 'NEUTRAL' | 'BEARISH';
  signalDirection?: 'LONG' | 'SHORT';
  showLabel?: boolean;
  className?: string;
}

export const CycleAlignmentIndicator: React.FC<CycleAlignmentIndicatorProps> = ({
  symbolCycles,
  btcMacroBias,
  signalDirection,
  showLabel = false,
  className = ''
}) => {
  if (!symbolCycles) {
    return <span className={`text-slate-500 ${className}`}>○</span>;
  }

  const { dcl, wcl, alignment } = symbolCycles;

  // Count alignments
  let alignedCount = 0;
  let totalChecks = 2; // DCL + WCL
  
  if (signalDirection === 'LONG') {
    if (dcl.bias === 'LONG' || dcl.bias === 'NEUTRAL') alignedCount++;
    if (wcl.bias === 'LONG' || wcl.bias === 'NEUTRAL') alignedCount++;
    if (btcMacroBias) {
      totalChecks++;
      if (btcMacroBias !== 'BEARISH') alignedCount++;
    }
  } else if (signalDirection === 'SHORT') {
    if (dcl.bias === 'SHORT' || dcl.bias === 'NEUTRAL') alignedCount++;
    if (wcl.bias === 'SHORT' || wcl.bias === 'NEUTRAL') alignedCount++;
    if (btcMacroBias) {
      totalChecks++;
      if (btcMacroBias !== 'BULLISH') alignedCount++;
    }
  } else {
    // No direction - just check overall health
    if (!dcl.is_failed) alignedCount++;
    if (!wcl.is_failed) alignedCount++;
    if (btcMacroBias) {
      totalChecks++;
      if (btcMacroBias !== 'BEARISH') alignedCount++;
    }
  }

  const ratio = alignedCount / totalChecks;
  
  let color = 'text-emerald-400';
  let icon = '●';
  let label = 'Aligned';
  
  if (ratio < 0.5) {
    color = 'text-red-400';
    icon = '●';
    label = 'Conflicting';
  } else if (ratio < 1) {
    color = 'text-amber-400';
    icon = '◐';
    label = 'Mixed';
  }

  // Check for failures
  if (dcl.is_failed || wcl.is_failed) {
    color = 'text-red-400 animate-pulse';
    icon = '◉';
    label = 'Failed';
  }

  return (
    <span className={`${color} ${className}`}>
      {icon}
      {showLabel && <span className="ml-1 text-xs">{label}</span>}
    </span>
  );
};

export default SignalCycleBadges;
