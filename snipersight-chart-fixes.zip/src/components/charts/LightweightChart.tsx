import { useRef, useEffect, useCallback, useState } from 'react';
import { createChart, ColorType, CrosshairMode, CandlestickSeries, BaselineSeries } from 'lightweight-charts';
import type { IChartApi, ISeriesApi, CandlestickData, Time, SeriesMarker } from 'lightweight-charts';
import { api } from '@/utils/api';
import { cn } from '@/lib/utils';
import { TimeframeLegend, TIMEFRAME_COLORS } from './TimeframeLegend';
import { Fire, Drop } from '@phosphor-icons/react';

interface OrderBlock {
    price_high: number;
    price_low: number;
    timestamp: number;
    type: 'bullish' | 'bearish';
    mitigated?: boolean;
    timeframe?: string; // Optional: for color-coding in overlay mode
    freshness_score?: number;
    displacement_strength?: number;
    mitigation_level?: number;
}

interface LiquidityZone {
    type: 'EQH' | 'EQL';
    priceLevel: number;
    strength: number;
}

interface LightweightChartProps {
    symbol: string;
    timeframe?: string;
    orderBlocks?: OrderBlock[];
    liquidityZones?: LiquidityZone[];  // Added for liquidity display
    entryPrice?: number;
    stopLoss?: number;
    takeProfit?: number;
    className?: string;
    title?: string; // Optional chart title
    showLegend?: boolean; // Show timeframe legend if OBs have timeframe property
}

interface CandleResponse {
    symbol: string;
    timeframe: string;
    candles: Array<{
        timestamp: string;
        open: number;
        high: number;
        low: number;
        close: number;
        volume: number;
    }>;
}

export function LightweightChart({
    symbol,
    timeframe = '15m',
    orderBlocks = [],
    liquidityZones = [],  // Added for liquidity display
    entryPrice,
    stopLoss,
    takeProfit,
    className = '',
    title,
    showLegend = false,
}: LightweightChartProps) {
    const containerRef = useRef<HTMLDivElement>(null);
    const chartRef = useRef<IChartApi | null>(null);
    const candleSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
    const zoneSeriesRefs = useRef<ISeriesApi<'Baseline'>[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [data, setData] = useState<CandlestickData[]>([]);
    const [showOBZones, setShowOBZones] = useState(true);
    const [showLiquidityZones, setShowLiquidityZones] = useState(true);  // Added toggle

    // Helper to determine reasonable limits based on timeframe
    const getLimitForTimeframe = (tf: string): number => {
        // Phemex API often requires higher limits (>=500) for consistent pagination/alignment
        switch (tf) {
            case '1M':
            case '1w':
                return 500; // Was 150, bumped for API safety
            case '1d':
                return 500; // Was 150
            case '4h':
            case '1h':
                return 500; // Good
            case '15m':
            case '5m':
            case '1m':
                return 1000; // Higher fidelity for lower TFs
            default:
                return 500;
        }
    };

    // Fetch candle data
    const fetchData = useCallback(async () => {
        try {
            // Clear previous data immediately to prevent "ghosting" (showing old symbol's chart)
            setData([]);
            setIsLoading(true);
            setError(null);

            const limit = getLimitForTimeframe(timeframe);
            const response = await api.getCandles(symbol, timeframe, limit);

            // Handle direct array, object with candles, OR wrapped data object
            const candles = Array.isArray(response)
                ? response
                : ((response as any)?.candles || (response as any)?.data?.candles || []);

            if (!candles || candles.length === 0) {
                throw new Error('No candle data available');
            }

            const candleData: CandlestickData[] = candles.map((candle: any) => {
                try {
                    const timestamp = new Date(candle.timestamp).getTime() / 1000;
                    if (isNaN(timestamp)) {
                        return null;
                    }
                    return {
                        time: timestamp as Time,
                        open: candle.open,
                        high: candle.high,
                        low: candle.low,
                        close: candle.close,
                    };
                } catch (e) {
                    return null;
                }
            }).filter((c: any) => c !== null) as CandlestickData[];

            if (candleData.length === 0) {
                throw new Error('Failed to parse any valid candles');
            }

            // Sort and Deduplicate to prevent "Time must be distinct" errors
            const sortedData = candleData
                .sort((a, b) => (a.time as number) - (b.time as number))
                .filter((item, index, self) =>
                    index === 0 || (item.time as number) > (self[index - 1].time as number)
                );

            if (sortedData.length === 0) {
                throw new Error('No valid candles after filtering');
            }

            setData(sortedData);
        } catch (err: any) {
            console.error('Failed to fetch candle data:', err);
            setError(err.message || 'Failed to load chart data');
        } finally {
            setIsLoading(false);
        }
    }, [symbol, timeframe]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    // Initialize chart
    useEffect(() => {
        if (!containerRef.current || data.length === 0) return;

        const chart = createChart(containerRef.current, {
            layout: {
                background: { type: ColorType.Solid, color: '#0a0f0a' },
                textColor: '#00ff88',
            },
            grid: {
                vertLines: { color: 'rgba(0, 255, 136, 0.1)' },
                horzLines: { color: 'rgba(0, 255, 136, 0.1)' },
            },
            crosshair: {
                mode: CrosshairMode.Normal,
                vertLine: {
                    color: '#00ff88',
                    width: 1,
                    style: 2,
                    labelBackgroundColor: '#00ff88',
                },
                horzLine: {
                    color: '#00ff88',
                    width: 1,
                    style: 2,
                    labelBackgroundColor: '#00ff88',
                },
            },
            rightPriceScale: {
                borderColor: 'rgba(0, 255, 136, 0.3)',
            },
            timeScale: {
                borderColor: 'rgba(0, 255, 136, 0.3)',
                timeVisible: true,
                secondsVisible: false,
            },
            width: containerRef.current.clientWidth,
            height: containerRef.current.clientHeight,
        });

        const candleSeries = chart.addSeries(CandlestickSeries, {
            upColor: '#00ff88',
            downColor: '#ff4444',
            borderUpColor: '#00ff88',
            borderDownColor: '#ff4444',
            wickUpColor: '#00ff88',
            wickDownColor: '#ff4444',
        });

        candleSeries.setData(data);
        chart.timeScale().fitContent();

        chartRef.current = chart;
        candleSeriesRef.current = candleSeries;

        // Handle resize
        const handleResize = () => {
            if (containerRef.current) {
                chart.applyOptions({
                    width: containerRef.current.clientWidth,
                    height: containerRef.current.clientHeight,
                });
            }
        };

        window.addEventListener('resize', handleResize);

        return () => {
            window.removeEventListener('resize', handleResize);
            chart.remove();
            chartRef.current = null;
            candleSeriesRef.current = null;
        };
    }, [data]);

    // Draw order blocks as SHADED ZONES and price levels
    useEffect(() => {
        if (!chartRef.current || !candleSeriesRef.current || data.length === 0) return;

        const chart = chartRef.current;
        const candleSeries = candleSeriesRef.current;

        // Clear previous zone series - with null checks to prevent "Value is undefined" errors
        // This can happen during React Strict Mode remounts or rapid component updates
        zoneSeriesRefs.current.forEach(series => {
            try {
                if (series && chart) {
                    chart.removeSeries(series);
                }
            } catch (e) {
                // Series may already be removed or chart may be disposed
                console.debug('[LightweightChart] Series cleanup skipped:', e);
            }
        });
        zoneSeriesRefs.current = [];

        // Create shaded zones for each order block (only if toggle enabled)
        if (showOBZones) {
            orderBlocks.forEach((ob, index) => {
                const isBullish = ob.type === 'bullish';

                // Use timeframe-specific color if available, otherwise default bull/bear colors
                let fillColor: string;
                let lineColor: string;

                if (ob.timeframe && TIMEFRAME_COLORS[ob.timeframe]) {
                    // Timeframe-specific color (for overlay mode)
                    const tfColor = TIMEFRAME_COLORS[ob.timeframe].color;
                    fillColor = tfColor.replace('rgb', 'rgba').replace(')', ', 0.2)');
                    lineColor = tfColor;
                } else {
                    // Default: Bullish = Cyan Blue, Bearish = Neon Orange (reduced opacity for translucency)
                    fillColor = isBullish ? 'rgba(6, 182, 212, 0.15)' : 'rgba(255, 138, 0, 0.15)';
                    lineColor = isBullish ? '#06b6d4' : '#ff8a00';
                }

                // Create baseline series for shaded zone
                const zoneSeries = chart.addSeries(BaselineSeries, {
                    baseValue: { type: 'price', price: ob.price_low },
                    topLineColor: 'transparent',
                    topFillColor1: fillColor,
                    topFillColor2: fillColor,
                    bottomLineColor: 'transparent',
                    bottomFillColor1: fillColor,
                    bottomFillColor2: fillColor,
                    lineWidth: 1,
                    priceLineVisible: false,
                    lastValueVisible: false,
                });

                // Fill the zone across the entire chart
                const zoneData = data.map(candle => ({
                    time: candle.time,
                    value: ob.price_high,
                }));

                zoneSeries.setData(zoneData);
                zoneSeriesRefs.current.push(zoneSeries);

                // NOTE: Removed OB boundary price lines (Top/Bot) to reduce chart clutter.
                // The shaded baseline zones provide sufficient visual indication.
            });
        } // End showOBZones conditional

        // Render Liquidity Zones (EQH/EQL) as horizontal bands
        if (showLiquidityZones && liquidityZones.length > 0) {
            liquidityZones.forEach((lz) => {
                // Purple bands for liquidity zones
                const fillColor = 'rgba(168, 85, 247, 0.2)';
                const lineColor = '#a855f7';
                
                // Calculate band size based on price range
                const prices = data.map(c => c.close as number);
                const priceRange = Math.max(...prices) - Math.min(...prices);
                const bandSize = priceRange * 0.003; // 0.3% band
                
                const zoneSeries = chart.addSeries(BaselineSeries, {
                    baseValue: { type: 'price', price: lz.priceLevel - bandSize },
                    topLineColor: lineColor,
                    topFillColor1: fillColor,
                    topFillColor2: fillColor,
                    bottomLineColor: 'transparent',
                    bottomFillColor1: fillColor,
                    bottomFillColor2: fillColor,
                    lineWidth: 1,
                    priceLineVisible: false,
                    lastValueVisible: false,
                });

                const zoneData = data.map(candle => ({
                    time: candle.time,
                    value: lz.priceLevel + bandSize,
                }));

                zoneSeries.setData(zoneData);
                zoneSeriesRefs.current.push(zoneSeries);
            });
        }

        // Always show entry/SL/TP lines (important trade levels)
        // axisLabelVisible: false removes the filled color rectangles on price axis
        if (entryPrice) {
            candleSeries.createPriceLine({
                price: entryPrice,
                color: '#00ff88',
                lineWidth: 2,
                lineStyle: 0,
                axisLabelVisible: false,
                title: 'E',
            });
        }

        if (stopLoss) {
            candleSeries.createPriceLine({
                price: stopLoss,
                color: '#ff4444',
                lineWidth: 2,
                lineStyle: 0,
                axisLabelVisible: false,
                title: 'SL',
            });
        }

        if (takeProfit) {
            candleSeries.createPriceLine({
                price: takeProfit,
                color: '#00ff88',
                lineWidth: 2,
                lineStyle: 0,
                axisLabelVisible: false,
                title: 'TP',
            });
        }
    }, [orderBlocks, liquidityZones, entryPrice, stopLoss, takeProfit, data, showOBZones, showLiquidityZones]);

    return (
        <div className={cn('relative w-full h-full bg-[#0a0f0a] rounded-lg overflow-hidden', className)}>
            {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-[#0a0f0a]/90 z-20">
                    <div className="flex flex-col items-center gap-3">
                        <div className="w-8 h-8 border-2 border-[#00ff88] border-t-transparent rounded-full animate-spin" />
                        <span className="text-sm text-[#00ff88]/70 font-mono">Loading chart...</span>
                    </div>
                </div>
            )}

            {error && (
                <div className="absolute inset-0 flex items-center justify-center bg-[#0a0f0a]/90 z-20">
                    <div className="flex flex-col items-center gap-3 max-w-md px-4">
                        <div className="text-2xl">📊</div>
                        <p className="text-sm text-red-400 text-center font-mono">{error}</p>
                        <button
                            onClick={fetchData}
                            className="px-4 py-2 bg-[#00ff88]/10 hover:bg-[#00ff88]/20 border border-[#00ff88]/30 rounded text-sm text-[#00ff88] font-mono transition-colors"
                        >
                            Retry
                        </button>
                    </div>
                </div>
            )}


            {/* Optional Chart Title */}
            {title && (
                <div className="absolute top-2 left-1/2 -translate-x-1/2 z-30">
                    <div className="px-4 py-1.5 rounded bg-black/70 backdrop-blur-sm border border-[#00ff88]/30">
                        <span className="text-sm font-mono font-bold text-[#00ff88]">{title}</span>
                    </div>
                </div>
            )}

            {/* Symbol and Timeframe badges */}
            <div className="absolute top-2 left-2 flex items-center gap-2 z-30">
                <div className="px-3 py-1.5 rounded bg-black/70 backdrop-blur-sm border border-[#00ff88]/40">
                    <span className="text-sm font-mono font-bold text-[#00ff88]">{symbol}</span>
                </div>
                <div className="px-3 py-1.5 rounded bg-[#00ff88]/10 backdrop-blur-sm border border-[#00ff88]/30">
                    <span className="text-sm font-mono font-bold text-[#00ff88]">{timeframe}</span>
                </div>
            </div>

            {/* OB Toggle Button - Bottom left */}
            <div className="absolute bottom-4 left-2 flex items-center gap-2 z-30">
                <button
                    onClick={() => setShowOBZones(!showOBZones)}
                    className={cn(
                        "p-2 rounded-lg backdrop-blur-md border-2 transition-all shadow-lg hover:scale-105 active:scale-95",
                        showOBZones
                            ? "bg-emerald-500/30 border-emerald-400 text-emerald-300"
                            : "bg-black/70 border-zinc-600 text-zinc-400 hover:border-zinc-400"
                    )}
                    title={`Toggle Order Block Zones (${orderBlocks.length} OBs)`}
                >
                    <Fire size={16} weight="bold" />
                </button>
                
                {/* Liquidity Toggle Button */}
                {liquidityZones.length > 0 && (
                    <button
                        onClick={() => setShowLiquidityZones(!showLiquidityZones)}
                        className={cn(
                            "p-2 rounded-lg backdrop-blur-md border-2 transition-all shadow-lg hover:scale-105 active:scale-95",
                            showLiquidityZones
                                ? "bg-purple-500/30 border-purple-400 text-purple-300"
                                : "bg-black/70 border-zinc-600 text-zinc-400 hover:border-zinc-400"
                        )}
                        title={`Toggle Liquidity Zones (${liquidityZones.length} zones)`}
                    >
                        <Drop size={16} weight="bold" />
                    </button>
                )}
            </div>

            {/* Timeframe Legend (for overlay mode) */}
            {showLegend && orderBlocks.some(ob => ob.timeframe) && (
                <div className="absolute bottom-2 left-2 right-2 z-30">
                    <div className="px-3 py-2 rounded bg-black/70 backdrop-blur-sm border border-[#00ff88]/20">
                        <TimeframeLegend
                            timeframes={Array.from(new Set(orderBlocks.map(ob => ob.timeframe).filter(Boolean))).map(tf => ({
                                tf: tf!,
                                color: TIMEFRAME_COLORS[tf!]?.color || '#888',
                            }))}
                        />
                    </div>
                </div>
            )}

            <div ref={containerRef} className="w-full h-full" />
        </div>
    );
}
